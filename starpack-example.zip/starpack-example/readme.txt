I will not maintain the starpack build environment because I have TclDevKit.
But to help you build a single executable by yourself, I made an example.

It's not difficult because TkSQLite source is a single file.

Here's what build.bat does:

When you have made changes to tksqlite.tcl (> 0.6.3),
copy it into following directory.

tksqlite.vfs\lib\app-tksqlite\

I have copied all the dependent packages manually into lib directory.
So what you need to do is just one command.

tclsh sdx.kit wrap tksqlite.exe -runtime tclkit-gui-8513.exe

Prerequisites:
ActiveTcl (> 8.5.11.1)
tclkit-gui-8513.exe or basekit (included in ActiveTcl).
